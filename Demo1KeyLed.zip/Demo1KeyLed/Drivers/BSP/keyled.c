/*
 * keyled.c
 *
 *  Created on: Mar 6, 2024
 *      Author: 38489
 */

#include "keyled.h"

KEYS ScanPressedKey(uint32_t timeout) {
	KEYS key = KEY_NONE;

	GPIO_PinState keyState;   //引脚的输入状态

	uint32_t tickstart = HAL_GetTick();  //当前的时间计数值

	while (1) {
#ifdef KEY0_Pin

		keyState = HAL_GPIO_ReadPin(KEY0_GPIO_Port, KEY0_Pin);
		if (keyState == GPIO_PIN_RESET) {
			HAL_Delay(20);
			keyState = HAL_GPIO_ReadPin(KEY0_GPIO_Port, KEY0_Pin);
			if (keyState == GPIO_PIN_RESET) {
				return KEY_RIGHT;
			}
		}
#endif

#ifdef KEY1_Pin
		keyState = HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin);
		if (keyState == GPIO_PIN_RESET) {
			HAL_Delay(20);
			keyState = HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin);
			if (keyState == GPIO_PIN_RESET) {
				return KEY_LEFT;
			}
		}
#endif

#ifdef KEY2_Pin
		keyState = HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin);
		if (keyState == GPIO_PIN_RESET) {
			HAL_Delay(20);
			keyState = HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin);
			if (keyState == GPIO_PIN_RESET) {
				return KEY_DOWN;
			}
		}
#endif

		if (timeout != KEY_WAIT_ALWAYS) {
			if ((HAL_GetTick() - tickstart) > timeout) {
				break;
			}
		}
	}

	return key;
}
