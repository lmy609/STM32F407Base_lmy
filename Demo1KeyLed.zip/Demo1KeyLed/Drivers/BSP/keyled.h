/*
 * keyled.h
 *
 *  Created on: Mar 6, 2024
 *      Author: 38489
 */

#ifndef BSP_KEYLED_H_
#define BSP_KEYLED_H_

#include "main.h"

//按键枚举类型
typedef enum{
	KEY_NONE = 0,
	KEY_LEFT,
	KEY_RIGHT,
	KEY_DOWN
}KEYS;

#define KEY_WAIT_ALWAYS 0

KEYS ScanPressedKey(uint32_t timeout);

#ifdef LED0_Pin
	#define LED0_ON  	HAL_GPIO_WritePin(LED0_GPIO_Port, LED0_Pin, GPIO_PIN_RESET)
	#define LED0_OFF 	HAL_GPIO_WritePin(LED0_GPIO_Port, LED0_Pin, GPIO_PIN_SET)
	#define LED0_Toggle	HAL_GPIO_TogglePin(LED0_GPIO_Port, LED0_Pin);
#endif


#ifdef LED1_Pin
	#define LED1_ON  	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET)
	#define LED1_OFF 	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET)
	#define LED1_Toggle	HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
#endif

#endif /* BSP_KEYLED_H_ */
